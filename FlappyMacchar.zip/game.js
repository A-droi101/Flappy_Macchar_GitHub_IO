
const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");

let frames = 0;
const DEGREE = Math.PI/180;

const sprite = new Image();
sprite.src = "sprite.png";

const state = {
    current : 0,
    getReady : 0,
    game : 1,
    over : 2
};

canvas.addEventListener("click", function(event){
    switch(state.current){
        case state.getReady:
            state.current = state.game;
            break;
        case state.game:
            bird.flap();
            break;
        case state.over:
            pipes.reset();
            bird.speedReset();
            score.reset();
            state.current = state.getReady;
            break;
    }
});

const bird = {
    animation: [
        {sX: 276, sY: 112},
        {sX: 276, sY: 139},
        {sX: 276, sY: 164},
        {sX: 276, sY: 139}
    ],
    x : 50,
    y : 150,
    w : 34,
    h : 26,

    radius : 12,

    frame : 0,

    gravity : 0.25,
    jump : 4.6,
    speed : 0,
    rotation : 0,

    draw : function(){
        let bird = this.animation[this.frame];

        ctx.save();
        ctx.translate(this.x, this.y);
        ctx.rotate(this.rotation);
        ctx.drawImage(sprite, bird.sX, bird.sY, this.w, this.h, -this.w/2, -this.h/2, this.w, this.h);

        ctx.restore();
    },

    flap : function(){
        this.speed = -this.jump;
    },

    update: function(){
        this.period = state.current == state.getReady ? 10 : 5;
        this.frame += frames % this.period == 0 ? 1 : 0;
        this.frame = this.frame % this.animation.length;

        if(state.current == state.getReady){
            this.y = 150;
            this.rotation = 0 * DEGREE;
        } else {
            this.speed += this.gravity;
            this.y += this.speed;

            if(this.y + this.h/2 >= canvas.height){
                this.y = canvas.height - this.h/2;
                if(state.current == state.game){
                    state.current = state.over;
                }
            }

            if(this.speed >= this.jump){
                this.rotation = 90 * DEGREE;
                this.frame = 1;
            } else {
                this.rotation = -25 * DEGREE;
            }
        }
    },

    speedReset : function(){
        this.speed = 0;
    }
};

function draw(){
    ctx.fillStyle = "#70c5ce";
    ctx.fillRect(0, 0, canvas.width, canvas.height);

    bird.draw();
}

function update(){
    bird.update();
}

function loop(){
    update();
    draw();
    frames++;

    requestAnimationFrame(loop);
}

loop();
