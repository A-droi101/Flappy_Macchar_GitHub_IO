
const canvas = document.getElementById("gameCanvas");
const ctx = canvas.getContext("2d");

let frames = 0;
const DEGREE = Math.PI/180;

const sprite = new Image();
sprite.src = "https://i.imgur.com/EaZ7aIn.png"; // Macchar image

const state = {
    current: 0,
    getReady: 0,
    game: 1,
    over: 2
};

canvas.addEventListener("click", function(evt){
    switch(state.current){
        case state.getReady:
            state.current = state.game;
            break;
        case state.game:
            bird.flap();
            break;
        case state.over:
            location.reload();
            break;
    }
});

const bird = {
    x: 50,
    y: 150,
    w: 34,
    h: 26,
    radius: 12,
    frame: 0,
    gravity: 0.25,
    jump: 4.6,
    speed: 0,
    rotation: 0,

    draw: function(){
        ctx.save();
        ctx.translate(this.x, this.y);
        ctx.rotate(this.rotation);
        ctx.drawImage(sprite, 0, 0, 34, 26, -this.w/2, -this.h/2, this.w, this.h);
        ctx.restore();
    },

    flap: function(){
        this.speed = -this.jump;
    },

    update: function(){
        if(state.current == state.getReady){
            this.y = 150;
            this.rotation = 0 * DEGREE;
        } else {
            this.speed += this.gravity;
            this.y += this.speed;

            if(this.y + this.h/2 >= canvas.height){
                this.y = canvas.height - this.h/2;
                if(state.current == state.game){
                    state.current = state.over;
                }
            }

            if(this.speed >= this.jump){
                this.rotation = 90 * DEGREE;
            } else {
                this.rotation = -25 * DEGREE;
            }
        }
    }
};

function draw(){
    ctx.fillStyle = "#70c5ce";
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    bird.draw();
}

function update(){
    bird.update();
}

function loop(){
    update();
    draw();
    frames++;
    requestAnimationFrame(loop);
}

loop();
